CREATE PROCEDURE find(IN keyword VARCHAR(100))
  begin
 
-- select * from v_columns  where  ((col_name LIKE '%'+@keyword+'%'） or  （col_remark  like   '%'+@keyword+'%')）;
select * from v_columns where col_name LIKE  CONCAT('%',keyword,'%')   or  col_remark LIKE  CONCAT('%',keyword,'%') ;

end;


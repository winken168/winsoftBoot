CREATE VIEW v_columns AS
  SELECT
    `a`.`TABLE_NAME`                          AS `tb_name`,
    `a`.`TABLE_COMMENT`                       AS `tb_remark`,
    `b`.`COLUMN_NAME`                         AS `col_name`,
    `b`.`COLUMN_COMMENT`                      AS `col_remark`,
    `b`.`COLUMN_TYPE`                         AS `col_type_len`,
    (CASE WHEN (`b`.`COLUMN_KEY` = 'PRI')
      THEN 1
     ELSE 0 END)                              AS `col_pk`,
    (CASE WHEN (`b`.`IS_NULLABLE` = 'YES')
      THEN 1
     ELSE 0 END)                              AS `colnull`,
    `b`.`DATA_TYPE`                           AS `col_type`,
    (CASE WHEN isnull(`b`.`CHARACTER_MAXIMUM_LENGTH`)
      THEN `b`.`NUMERIC_PRECISION`
     ELSE `b`.`CHARACTER_MAXIMUM_LENGTH` END) AS `col_len`,
    (CASE WHEN ((isnull(`b`.`NUMERIC_PRECISION`) = FALSE) AND (isnull(`b`.`NUMERIC_SCALE`) = FALSE))
      THEN `b`.`NUMERIC_SCALE`
     ELSE 0 END)                              AS `col_scale`
  FROM (`information_schema`.`TABLES` `a` LEFT JOIN `information_schema`.`COLUMNS` `b`
      ON ((`a`.`TABLE_NAME` = `b`.`TABLE_NAME`)))
  WHERE (`a`.`TABLE_SCHEMA` = database())
  ORDER BY `a`.`TABLE_NAME`;


CREATE PROCEDURE pro_test1()
  BEGIN             -- 开始

         -- 可以写多个sql语句;          -- sql语句+流程控制

         SELECT * FROM sys_user;
         SELECT * FROM sys_user;

END;

